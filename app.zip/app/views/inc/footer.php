<footer>
<p>&copy; 2020 - All right reserved - Zvi Eshel</p>
</footer>
<script src="<?php echo '/' . SITE_NAME . '/public/js/main.js';?>"></script>
</body>
</html>