<?php
@include('inc/header.php')
?>

<div class="container">
  
  <header><h1><?php echo $data['title']; ?></h1></header>
  <div class="main p-2">    
   
  </div>

</div>

<?php
@include('inc/footer.php');




