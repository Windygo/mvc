<?php

require_once('../app/bootstrap.php');

// Init core library
$init = new Core;